@echo off
title ForgeMiner - LuckyPool EU (BTX)
cd /d "%~dp0.."

rem ================ EDIT THESE ================
set "FORGE_WALLET=YOUR_BTX_ADDRESS"
set "FORGE_WORKER=PC"
rem ===========================================

rem LuckyPool's new BTX protocol: plain JSON on port 8666.
rem
rem Do NOT put stratum+tls:// in front of this address. That scheme is what switches on the old
rem encrypted framing, and the new port does not speak it -- every line would come back -32601.
rem
rem If this one will not connect, use LuckyPool-EU-old.bat (the 8665 port) until the pool finishes
rem moving this node over.
set "FORGE_POOL=btx-eu.lproute.com:8666"

rem Call the miner by explicit path. On machines with NoDefaultCurrentDirectoryInExePath=1 (a common
rem hardening setting) cmd does NOT search the current directory for executables, so a bare
rem "forge.exe" is not found even right after cd.
set "FORGE=%~dp0..\forge.exe"
if not exist "%FORGE%" set "FORGE=%~dp0forge.exe"
if not exist "%FORGE%" (
  echo.
  echo forge.exe not found.
  echo Keep this .bat inside the extracted folder, next to forge.exe or one level below it.
  echo.
  pause
  exit /b 1
)
"%FORGE%" --algorithm btx
echo.
echo === miner stopped ===
pause
