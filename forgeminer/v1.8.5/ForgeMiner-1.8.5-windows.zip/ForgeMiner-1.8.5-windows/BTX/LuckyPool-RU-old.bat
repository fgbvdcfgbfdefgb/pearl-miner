@echo off
title ForgeMiner - LuckyPool RU OLD port (BTX)
cd /d "%~dp0.."

rem ================ EDIT THESE ================
set "FORGE_WALLET=YOUR_BTX_ADDRESS"
set "FORGE_WORKER=PC"
rem ===========================================

rem The OLD LuckyPool port, 8665. The pool is retiring it in favour of the plain-JSON protocol on
rem 8666 -- use LuckyPool-RU.bat instead. This file is here so nobody is stranded while the move
rem is happening, and it stops working the day the pool switches 8665 off.
rem
rem This port serves BTX over an encrypted connection only, and the stratum+tls:// scheme is what
rem selects it. A bare address here connects to nothing.
set "FORGE_POOL=stratum+tls://btx-ru.lproute.com:8665"

rem Call the miner by explicit path. On machines with NoDefaultCurrentDirectoryInExePath=1 (a common
rem hardening setting) cmd does NOT search the current directory for executables, so a bare
rem "forge.exe" is not found even right after cd.
set "FORGE=%~dp0..\forge.exe"
if not exist "%FORGE%" set "FORGE=%~dp0forge.exe"
if not exist "%FORGE%" (
  echo.
  echo forge.exe not found.
  echo Keep this .bat inside the extracted folder, next to forge.exe or one level below it.
  echo.
  pause
  exit /b 1
)
"%FORGE%" --algorithm btx
echo.
echo === miner stopped ===
pause
