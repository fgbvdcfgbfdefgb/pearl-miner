@echo off
title ForgeMiner - Kryptex US (Conflux)
cd /d "%~dp0.."

rem ================ EDIT THESE ================
set "FORGE_WALLET=YOUR_CFX_ADDRESS"
set "FORGE_WORKER=PC"
rem ===========================================

rem Conflux needs a card with about 8.6 GB of free video memory, and that grows slowly as the
rem chain advances. An 8 GB card cannot mine this coin; the miner says so at startup with the
rem actual numbers rather than failing partway through building.
set "FORGE_POOL=cfx-us.kryptex.network:7027"

rem Call the miner by explicit path. On machines with NoDefaultCurrentDirectoryInExePath=1 (a common
rem hardening setting) cmd does NOT search the current directory for executables, so a bare
rem "forge.exe" is not found even right after cd.
set "FORGE=%~dp0..\forge.exe"
if not exist "%FORGE%" set "FORGE=%~dp0forge.exe"
if not exist "%FORGE%" (
  echo.
  echo forge.exe not found.
  echo Keep this .bat inside the extracted folder, next to forge.exe or one level below it.
  echo.
  pause
  exit /b 1
)
"%FORGE%" --algorithm octopus
echo.
echo === miner stopped ===
pause
