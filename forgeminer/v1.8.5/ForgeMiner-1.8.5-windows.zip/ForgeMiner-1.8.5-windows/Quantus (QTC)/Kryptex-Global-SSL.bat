@echo off
title ForgeMiner - Kryptex Global (Quantus, SSL)
cd /d "%~dp0.."

rem ================ EDIT THESE ================
set "FORGE_WALLET=YOUR_QUANTUS_ADDRESS"
set "FORGE_WORKER=PC"
rem ===========================================

set "FORGE_POOL=ssl://qtc.kryptex.network:8049"

rem Call the miner by explicit path. On machines with NoDefaultCurrentDirectoryInExePath=1 (a common
rem hardening setting) cmd does NOT search the current directory for executables, so a bare
rem "forge.exe" is not found even right after cd.
set "FORGE=%~dp0..\forge.exe"
if not exist "%FORGE%" set "FORGE=%~dp0forge.exe"
if not exist "%FORGE%" (
  echo.
  echo forge.exe not found.
  echo Keep this .bat inside the extracted folder, next to forge.exe or one level below it.
  echo.
  pause
  exit /b 1
)
"%FORGE%" --algorithm quantus
echo.
echo === miner stopped ===
pause
