ForgeMiner - native NVIDIA GPU miner
====================================

Eleven coins, one binary, no dependencies.
Quantus (QTC) - Pearl (PRL) - Xelis (XEL) - Ravencoin (RVN) - Quai (QUAI)
Neurai (XNA) - Cryptix (CYTX) - QubitCoin (QTC) - BTX - Conflux (CFX) - NOID

SETTING UP THE FLIGHT SHEET
---------------------------
ForgeMiner installs as a HiveOS custom miner.

  Miner name        Custom
  Installation URL  https://github.com/0xHashRaptor/ForgeMiner/releases/download/v1.8.5/ForgeMiner-1.8.5.tar.gz
  Hash algorithm    pearlhash   (any label is fine, the miner reads Extra config)
  Wallet and worker template   %WAL%.%WORKER_NAME%
  Pool URL          prl.kryptex.network:7048

To upgrade, change the version in that URL (both places) and update the
flight sheet. HiveOS installs a custom miner once per URL: with an
unchanged URL it reports "Already installed" and keeps the old version.
Rigs set up with the old .../releases/latest/download/ForgeMiner.tar.gz
link stay on the release they first installed; switch them to the
versioned URL.

EXTRA CONFIG
------------
This box takes both forms, one per line, and you can mix them:

  FORGE_ALGO=xelis            or pearlhash / qhash / kawpow / cryptix / btx / cfx /
                              noid / quantus
  FORGE_COIN=xna              KawPow only: rvn | quai | xna
  --gpu 0,1,3                 mine only these cards
  --cclk 1500 --moff 1000     overclock: also --coff / --mclk / --plimit
  --fan 70                    or --fan-curve 45:30,60:55,70:75,80:100
  --cmp-install               unlock any CMP 40HX/50HX/70HX/90HX on this rig (see below)
  --temp-limit 80 --temp-resume 70   pause on overheat, resume once cooled

Hashrate, temperatures and shares show up in the HiveOS dashboard on their
own - no extra flag is needed for that.

ENCRYPTED POOLS (TLS)
---------------------
Put the address in the flight sheet exactly as the pool gives it. A plain
host:port works even on a TLS port - the miner detects TLS by itself. To be
explicit, write ssl://host:port (stratum+ssl:// and tls:// are also accepted),
or add  --tls true  to the extra config arguments.

TLS works on every coin and is detected on its own, so a TLS-only pool needs
nothing typed by hand - which matters in a flight sheet, where there is nowhere
to put ssl:// anyway. Comma-separated backup pools work on every coin too.

PEARL AND ALPHAPOOL
-------------------
Every Pearl pool is mined the same way, AlphaPool included: it takes standard
stratum on port 5571 (ru1 / eu1 / us1 / us2 / sg1 .alphapool.tech:5571).
Older AlphaPool settings keep working - port 5566 is moved to 5571 and
FORGE_PROTO=alpha is ignored, each with one line in the log saying so.

NOID (PARANO1D)
---------------
  FORGE_ALGO=noid
  Pools   eu2.innovlab.cc:19601  or  ru.innovlab.cc:19601   (TLS)
          noid.suprnova.cc:3339

NOID runs on the RTX 30-series (Ampere) and newer, CMP 90HX included. On a
mixed rig the older cards stay idle and say so while the rest mine it.

QUANTUS
-------
  FORGE_ALGO=quantus
  Pools   qtc-eu.kryptex.network:7049   qtc-ru.kryptex.network:7049
          qtc.kryptex.network:7049      (the same three on 8049 for TLS)
          eu.lproute.com:5660           ru.luckypool.io:5660

Quantus runs on the RTX 20-series (Turing) and newer, CMP 50HX and 90HX
included. Older cards stay idle and say so while the rest of the rig mines it.

Note the ticker: QTC belongs to two different coins. Quantus is the one this
section is about; QubitCoin is mined with FORGE_ALGO=qhash.

CMP HARDWARE UNLOCK  (Linux, 40HX/50HX/70HX/90HX, any kernel since 1.5.16)
---------------------------------------------------------------------------
CMP 40HX, 50HX, 70HX and 90HX ship with a hardware throttle. Forge can
install a hardware unlock helper on the rig itself - one command, one
reboot, the card then runs at full speed.

Builds from source for whatever kernel the rig is actually running - no
exact kernel pin needed anymore. NVIDIA driver 610.43.03 is still required.

Only the detected CMP cards are affected; the rest of your GPUs are
untouched. CMP 30HX is detected but never touched (permanent hardware
limitation, not a bug). CMP 170HX needs a separate tool.

  sudo forge --cmp-install     install and reboot (10-second cancel window)
  sudo forge --cmp-install --no-reboot   install only, reboot the rig yourself
  sudo forge --cmp-verify      print unlock status per card
  sudo forge --cmp-rollback    restore the previous driver from backup + reboot

Safe to leave --cmp-install at the end of the flight-sheet command line
forever - if the unlock is already active forge prints one line and drops
straight into mining. Do NOT leave --cmp-rollback or --cmp-verify there;
those are for manual use only.

Full guide, exit codes, FAQ:
  https://github.com/0xHashRaptor/ForgeMiner/wiki/CMP-unlock

OVERCLOCK, FANS, GPU SELECTION
------------------------------
Add any of these to the forge line:
  --gpu 0,1,3       mine only these cards (order as in nvidia-smi)
  --cclk 1500       lock core clock        --coff 200    core clock offset
  --mclk 5000       lock memory clock      --moff 1000   memory clock offset
  --plimit 130      power limit, watts
  --fan 70          static fan percent
  --fan-curve 45:30,60:55,70:75,80:100     temperature -> fan percent
A single value applies to every card; a comma list maps to the --gpu order.
Overclock and fan control need administrator/root. Fans are restored on exit.

DASHBOARD
---------
Add  --api-bind 0.0.0.0:7777  and open  http://<this-machine>:7777  in a
browser: live per-GPU hashrate, temperatures, power draw and share history.

SUPPORTED GPUS
--------------
NVIDIA from the GTX 10-series (Pascal) through the RTX 50-series (Blackwell),
plus Tesla V100 and the CMP mining cards. The right kernel is picked for each
card at startup, so mixed rigs work and every card runs at its own best.
Two coins are narrower: NOID wants the RTX 30-series or newer and Quantus the
RTX 20-series or newer. Both say so per card, see above.

DEV FEE
-------
NOID 2.5%   Pearl 2%   Cryptix 2%   BTX 2%   Quantus 2%   Conflux 1.5%
QubitCoin 1%   Xelis 1%   Ravencoin / Quai / Neurai 0.7%

The fee is interleaved into the stream rather than mined in bursts, so your
pool graph has no dips, and it is verifiable on the pool. There is no second,
hidden fee.

LINKS
-----
Site         https://forgeminer.org
GitHub       https://github.com/0xHashRaptor/ForgeMiner
CMP unlock   https://github.com/0xHashRaptor/ForgeMiner/wiki/CMP-unlock
Telegram     https://t.me/ForgeMiner
Discord      https://discord.gg/CyU6ASQWSy
