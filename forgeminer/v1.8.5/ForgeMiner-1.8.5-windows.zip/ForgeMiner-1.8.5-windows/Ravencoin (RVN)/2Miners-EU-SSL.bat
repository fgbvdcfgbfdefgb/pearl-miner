@echo off
title ForgeMiner - 2Miners EU (Ravencoin, SSL)
cd /d "%~dp0.."

rem ================ EDIT THESE ================
set "FORGE_WALLET=YOUR_RVN_ADDRESS"
set "FORGE_WORKER=PC"
rem ===========================================

set "FORGE_POOL=ssl://rvn.2miners.com:16060"
set "FORGE_COIN=rvn"

rem Call the miner by explicit path. On machines with NoDefaultCurrentDirectoryInExePath=1 (a common
rem hardening setting, and set on the machine this was tested on) cmd does NOT search the current
rem directory for executables, so a bare "forge.exe" is not found even right after cd. The old flat
rem .bat files carried the same latent failure.
set "FORGE=%~dp0..\forge.exe"
if not exist "%FORGE%" set "FORGE=%~dp0forge.exe"
if not exist "%FORGE%" (
  echo.
  echo forge.exe not found.
  echo Keep this .bat inside the extracted folder, next to forge.exe or one level below it.
  echo.
  pause
  exit /b 1
)
"%FORGE%" --algorithm kawpow
echo.
echo === miner stopped ===
pause
