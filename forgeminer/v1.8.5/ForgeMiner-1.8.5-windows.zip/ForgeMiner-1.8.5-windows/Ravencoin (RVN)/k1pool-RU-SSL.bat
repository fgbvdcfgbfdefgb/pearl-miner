@echo off
title ForgeMiner - k1pool RU (Ravencoin, SSL)
cd /d "%~dp0.."

rem ================ EDIT THESE ================
set "FORGE_WALLET=YOUR_RVN_ADDRESS"
set "FORGE_WORKER=PC"
rem ===========================================

rem k1pool serves Ravencoin over TLS on ONE host only, and it is this one. Measured 31.08.2026 with a
rem real handshake against every plausible port:
rem   ru.rvn.k1pool.org:7861   plain AND TLS on the same port  <- the only TLS endpoint that works
rem   eu.rvn.k1pool.com:7861   plain only; a TLS hello is closed on
rem   eu.rvn.k1pool.com:17861  refuses connections outright
rem The old k1pool-EU-SSL.bat pointed at 17861 and could never have worked. This file replaces it.
rem
rem An explicitly stated scheme is obeyed and never second-guessed by the miner -- that is deliberate,
rem so the transport auto-detect cannot rescue a launcher that names the wrong one. The address here
rem has to be right, and this one is verified.
set "FORGE_POOL=ssl://ru.rvn.k1pool.org:7861"
set "FORGE_COIN=rvn"

rem Call the miner by explicit path. On machines with NoDefaultCurrentDirectoryInExePath=1 (a common
rem hardening setting, and set on the machine this was tested on) cmd does NOT search the current
rem directory for executables, so a bare "forge.exe" is not found even right after cd. The old flat
rem .bat files carried the same latent failure.
set "FORGE=%~dp0..\forge.exe"
if not exist "%FORGE%" set "FORGE=%~dp0forge.exe"
if not exist "%FORGE%" (
  echo.
  echo forge.exe not found.
  echo Keep this .bat inside the extracted folder, next to forge.exe or one level below it.
  echo.
  pause
  exit /b 1
)
"%FORGE%" --algorithm kawpow
echo.
echo === miner stopped ===
pause
