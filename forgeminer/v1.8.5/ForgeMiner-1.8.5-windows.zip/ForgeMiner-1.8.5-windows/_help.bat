@echo off
title ForgeMiner - help
cd /d "%~dp0"
set "FORGE=%~dp0forge.exe"
if not exist "%FORGE%" set "FORGE=%~dp0..orge.exe"
if not exist "%FORGE%" (
  echo forge.exe not found next to this file.
  pause
  exit /b 1
)
"%FORGE%" --version
echo.
"%FORGE%" --help
echo.
echo ================================================
pause
